export class Employee {
    empId:number=0;
    empName:string="";
    empDesig:string="";
    empSalary:number=0;

    constructor(){}

    
}

// export class Employee {
//     constructor(private empId:number,private empName:string,private empDesig:string,
//         private empSalary:number){
//     }
// }