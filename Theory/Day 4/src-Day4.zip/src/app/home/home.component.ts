import { Component} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent{

  constructor(private aroute:ActivatedRoute,private router:Router){}

  showChild1(){
    this.router.navigate(['child1'],{relativeTo:this.aroute});
  }                                  //    /homeLink/child1
  showChild2(){
    this.router.navigate(['child2'],{relativeTo:this.aroute});
  }

}


