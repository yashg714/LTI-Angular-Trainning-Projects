import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  template: `
    <!--<img src='{{imagePath}}'/>-->
    <img [src]='imagePath' width="200px" height="200px"/><br><br><br>
    <button [disabled]='isDisabled'>Click</button>
    <!--<div>{{data}}</div>-->
    <!--<div [innerHTML]='data'></div>-->
    <!--<div innerHTML='{{data}}'></div>-->
    <!--<div innerText='{{data}}'></div>-->
    <div [innerText]='data'></div>
  `,
  styles: [
  ]
})
export class SampleComponent {
    imagePath="./assets/images/ceo.jpg";
    isDisabled:boolean=true;
    data:string="<h2>Employee Data</h2>";
}
