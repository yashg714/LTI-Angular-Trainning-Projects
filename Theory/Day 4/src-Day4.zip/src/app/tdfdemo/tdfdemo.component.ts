import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Register } from '../register';

@Component({
  selector: 'app-tdfdemo',
  templateUrl: './tdfdemo.component.html',
  styleUrls: ['./tdfdemo.component.css']
})
export class TdfdemoComponent implements OnInit {
  reg:Register=new Register();
  constructor() {
    this.reg.userName="Simant";
    this.reg.userPassword="Simant@123";
    this.reg.userEmail="simant@lti.com";
    this.reg.userPhone="9867585839";
   }

  ngOnInit(): void {
    console.log(JSON.stringify(this.reg));
  }

  registerUser(){
    console.log(JSON.stringify(this.reg));
  }

  // registerUser(regForm:NgForm){
  //   console.log(JSON.stringify(regForm.value));
  // }
}
