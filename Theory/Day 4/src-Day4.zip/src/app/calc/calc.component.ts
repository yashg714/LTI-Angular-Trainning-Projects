import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.css']
})
export class CalcComponent implements OnInit {
  num1:number=0;
  num2:number=0;
  result:number=0;
  constructor() { }

  ngOnInit(): void {
  }

  sum(option:number){
    switch (option) {
      case 1:
        this.result=Number(this.num1)+Number(this.num2);
        break;
      case 2:
        this.result=Number(this.num1)-Number(this.num2);
        break;
      case 3:
        this.result=Number(this.num1)*Number(this.num2);
        break;
      case 4:
        this.result=Number(this.num1)/Number(this.num2);
        break;
    }
  }












}
