import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-binding',
  templateUrl: './event-binding.component.html',
  styleUrls: ['./event-binding.component.css']
})
export class EventBindingComponent implements OnInit {

  textValue:any;
  isDisabled:boolean=true;
  name:string="";

  constructor() { }

  ngOnInit(): void {
  }

  sayHello(){
    console.log("Hello Friends");
  }
  divClicked(){
    console.log("Div was clicked");
  }

  luckyNumber(){
    return Math.floor(Math.random()*10+1);
  }

  getText(event:any){
    this.textValue=event.target.value;
  }

  toggle(val:boolean){
    this.isDisabled=val;
  }
}
