export class Register{
    userName:string="";
    userPassword:string="";
    userEmail:string="";
    userPhone:string="";
}