export class MyComment{
    postId:number;
    id:number;
    name:string;
    email:string;
    body:string;
}
