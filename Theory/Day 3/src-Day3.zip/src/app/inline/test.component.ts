import { Component } from "@angular/core";

@Component({
    selector:'app-test',
    template:
    `
    <p>This is test page</p>
    <div>This is test div</div>
    <!--
    Hi, {{name}}
    <div>
        {{name}}
    </div>
    <input type="text" value={{name}}/>
    -->
    <h2>{{'First Name: '+firstName+' Last Name: '+lastName}}</h2>
    <div>{{num1*num2}}</div>
    <img src="{{imagePath}}" alt="Image not supported" width="200px" height="200px">
    <div>{{add()}}</div>
    `,
    styles:[]
})
export class TestComponent{
    firstName:string="Simant";
    lastName:string="Setu";
    num1=10;
    num2=20;
    imagePath="./assets/images/lti.jpg";
    
    add() :number {
        return this.num1+this.num2;
    }
}




