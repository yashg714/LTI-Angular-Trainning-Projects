import { Component, OnInit } from '@angular/core';
import { MyComment } from '../Comment';
import { MyapiService } from '../myapi.service';
import { Post } from '../post';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {
  userId:number;
  comments:MyComment[]=[];
  posts:Post[]=[];
  constructor(private myApiService:MyapiService) { }

  ngOnInit(): void {
    this.myApiService.getAllComments().subscribe(
      userComments=>{
        console.log(JSON.stringify(userComments));
        this.comments=userComments;
      }
    );
  }

  getAllPostsByUserId(){
      this.myApiService
      .getAllPostsByUserId(this.userId)
      .subscribe(
        allPosts=>{
            this.posts=allPosts;
        }
      );
  }

}
